﻿using MyProject.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyProject.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Product()
        {
            return View();
        }
        public ActionResult SignIn()
        {
            return View();
        }
        public ActionResult SignUp()
        {
            return View();
        }
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogin(string adminid,string password)
        {
            string query = "select * from tbl_adminlogin where adminid='" + adminid +"'and password='" +password+"' ";
            DBManager db = new DBManager();
            DataTable dt = db.ExecuteSelect(query);
            if(dt.Rows.Count>0)
            {
                Session["admin"] = adminid;
                return RedirectToAction("index","admin");
            }
            else
            {
                return Content("<script>alert('Id or Password is invalid');location.href='/home/AdminLogin'</script>");
            }
        }
        public ActionResult contact()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Contact(string name, string email, long mobno, string message)
        {
            DBManager dm = new DBManager();
            int x=dm.ExecuteInsertUpdateDelet("isert into tbl_contact values('"+name+"',"+ mobno+",'"+ email + "','"+message+"','"+DateTime.Now+"')");
            if (x > 0)
                Response.Write("<script>alert('Thanks for contacting with us...')</script>");
            else
                Response.Write("<script>alert('Do not ')");
            return View();
        }
       
    }
}